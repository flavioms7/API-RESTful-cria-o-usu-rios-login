package com.apinewuserlogin.apinewuserlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApinewuserloginApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApinewuserloginApplication.class, args);
	}

}
